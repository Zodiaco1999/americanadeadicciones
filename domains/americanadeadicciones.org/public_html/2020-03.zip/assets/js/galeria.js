$(".picture").mouseenter(function(){
 $(this).animate({opacity:1},200);
});

$(".picture").mouseleave(function(){
 $(this).animate({opacity:0.8},200);
});